import pygame
import random
# Inicialização do Pygame
pygame.init()

# Configurações da tela
largura = 1600
altura = 900
tela = pygame.display.set_mode((largura, altura))
pygame.display.set_caption("Exemplo de Telas com Botões")

# Carregamento das imagens
inicio = pygame.image.load("inicio.png")
login = pygame.image.load("login.png")
nome = pygame.image.load("nome.png")
acerto = pygame.image.load("acerto.png")
erro = pygame.image.load("erro.png")
nivel_1 = pygame.image.load("nivel 1.png")
nivel_2 = pygame.image.load("nivel 2.png")
nivel_3 = pygame.image.load("nivel 3.png")
nivel_4 = pygame.image.load("nivel 4.png")
nivel_5 = pygame.image.load("nivel 5.png")
nivel_6 = pygame.image.load("nivel 6.png")
nivel_7 = pygame.image.load("nivel 7.png")
como_jogar_1 = pygame.image.load("sobre_jogo.png")
criadores = pygame.image.load("criadores.png")
#agradecimento = pygame.image.load("agradecimento.png")
agradecimento_1 = pygame.image.load("agradecimento_ sala.png")
sobre_1 = pygame.image.load("sobre_jogo.png")
instrutores = pygame.image.load("intrutores.png")
configuracao = pygame.image.load("configuração.png")
acampamento_1 = pygame.image.load("acampamento 1.png")
acampamento_2 = pygame.image.load("acampamento 2.png")
acampamento_3 = pygame.image.load("acampamento 3.png")
acampamento_4 = pygame.image.load("acampamento 4.png")
cafe_1 = pygame.image.load("cafe 1.png")
cafe_2 = pygame.image.load("cafe 2.png")
cafe_3 = pygame.image.load("cafe 3.png")
cafe_4 = pygame.image.load("cafe 4.png")
hospital_1 = pygame.image.load("hospital 1.png")
hospital_2 = pygame.image.load("hospital 2.png")
hospital_3 = pygame.image.load("hospital 3.png")
hospital_4 = pygame.image.load("hospital 4.png")
escola_1 = pygame.image.load("escola 1.png")
escola_2 = pygame.image.load("escola  2.png")
escola_3 = pygame.image.load("escola 3.png")
escola_4 = pygame.image.load("escola 4.png")
cinema_1 = pygame.image.load("cinema 1.png")
cinema_2 = pygame.image.load("cinema 2.png")
cinema_3 = pygame.image.load("cinema 3.png")
cinema_4 = pygame.image.load("cinema 4.png")
biblioteca_1 = pygame.image.load("biblioteca 1.png")
biblioteca_2 = pygame.image.load("biblioteca 2.png")
biblioteca_3 = pygame.image.load("biblioteca 3.png")
biblioteca_4 = pygame.image.load("biblioteca 4.png")
mercadinho_1 = pygame.image.load("mercado 1.png")
mercadinho_2 = pygame.image.load("mercado 2.png")
mercadinho_3 = pygame.image.load("mercado 3.png")
mercadinho_4 = pygame.image.load("mercado 4.png")
config_jogo = pygame.image.load("configuração jogo.png")
bloqueio_1 = pygame.image.load("bloqueio tela 2.png")
bloqueio_2 = pygame.image.load("bloqueio fase 3.png")
bloqueio_3 = pygame.image.load("bloqueio tela 4.png")
bloqueio_4 = pygame.image.load("bloqueio fase 5.png")
bloqueio_5 = pygame.image.load("bloqueio fase 7.png")
bloqueio_6 = pygame.image.load("bloqueio fase 7.png")
concluiu_1 = pygame.image.load("concluiu fase 1.png")
concluiu_2 = pygame.image.load("concluiu fase 2.png")
concluiu_3 = pygame.image.load("concluiu fase 4.png")
concluiu_4 = pygame.image.load("concluiu fase 4.png")
concluiu_5 = pygame.image.load("concluiu fase 5.png")
concluiu_6 = pygame.image.load("concluiu fase 6.png")
concluiu_7 = pygame.image.load("concluiu fase 7.png")
final = pygame.image.load("final.png")
final_15 = pygame.image.load("final_1.png")

# Cores
BRANCO = (255, 255, 255)
PRETO = (0, 0, 0)

#MOEDAS
moedas = 0

# Inicializa o texto dentro da caixa de texto como vazio
text = ''


#pontuação
pontuacao = 0
pontuacao_1 = 0
pontuacao_2 = 0
pontuacao_3 = 0
pontuacao_4 = 0
pontuacao_5 = 0
pontuacao_6 = 0
def tela_1():
    botao = pygame.Rect(510, 570, 570, 100)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_2()

        pygame.draw.rect(tela, PRETO, botao)

        tela.fill(BRANCO)
        tela.blit(inicio, (0, 0))

        pygame.display.flip()

    pygame.quit()


def tela_2():
    botao = pygame.Rect(1150, 590, 330, 80)
    running = True
    input_box = pygame.Rect(1180, 415, 2000, 53)
    color_inactive = pygame.Color('lightskyblue3')
    color_active = pygame.Color('dodgerblue2')
    color = color_inactive
    color_1 = PRETO
    text = ' '
    sei_la = "!"
    active = False
    font = pygame.font.Font(None, 50)

    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao.collidepoint(event.pos):
                    print(f"Login: {text}")
                    nome_1(text)
                if input_box.collidepoint(event.pos):
                    active = not active
                else:
                    active = False
                color = color_active if active else color_inactive
            elif event.type == pygame.KEYDOWN:
                if active:
                    if event.key == pygame.K_RETURN:
                        print(f"Login: {text}")
                        nome_1(text)
                    elif event.key == pygame.K_BACKSPACE:
                        text = text[:-1]
                    else:
                        text += event.unicode

        tela.fill(PRETO)
        tela.blit(login, (0, 0))
        txt_surface = font.render(text, True, color_1)
        width = max(200, txt_surface.get_width() + 10)
        input_box.w = width
        tela.blit(txt_surface, (input_box.x + 5, input_box.y + 5))


        pygame.display.flip()

    pygame.quit()

def nome_1(user_text):
    botao = pygame.Rect(730, 655, 130, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()


        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(nome, (0, 0))

        cor_hex = '#95241E'
        cor_rgb = tuple(int(cor_hex[i:i + 2], 16) for i in (1, 3, 5))

        # Cria um objeto de fonte
        font = pygame.font.Font('Moonlight.ttf', 55)

        # Renderiza o texto com a fonte criada
        nome_texto = font.render(user_text,  True, cor_rgb)

        # Desenha o texto na tela
        tela.blit(nome_texto, (400, 200))
        pygame.display.flip()

    pygame.quit()



def tela_3():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    tela_5()
                elif botao3.collidepoint(event.pos):
                    bloqueio_f1()
                elif botao4.collidepoint(event.pos):
                    bloqueio_f2()
                elif botao5.collidepoint(event.pos):
                    bloqueio_f3()
                elif botao6.collidepoint(event.pos):
                    bloqueio_f4()
                elif botao7.collidepoint(event.pos):
                    bloqueio_f5()
                elif botao8.collidepoint(event.pos):
                    bloqueio_f6()
                elif botao12.collidepoint(event.pos):
                    tela_4()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_1, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render("  " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 36)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))


        pygame.display.flip()

    pygame.quit()

def tela_4():
    global moedas
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pygame.quit()


        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(configuracao, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_1()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()

    pygame.quit()

def credito_1():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito()

            pygame.draw.rect(tela, BRANCO, botao1)
            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_2():
    botao = pygame.Rect(1425, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_1()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()


#configuração do jogo
def config_l1():
    global moedas
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                 como_jogar_l1()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontucao = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()

def como_jogar_l1():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l1():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
               credito_l()


            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, PRETO, botao1)

            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela



        pygame.display.flip()
    pygame.quit()


def credito_l2():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l1()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l1()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()



def tela_5():
    global moedas
    global pontuacao
    botao = pygame.Rect(245, 375, 85, 90)
    botao1 = pygame.Rect(730, 380, 85, 85)
    botao2 = pygame.Rect(245, 520, 85, 85)
    botao3 = pygame.Rect(730, 520, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                pontuacao += 1
                tela_6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(acampamento_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_6():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_9()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))

        pygame.display.flip()

    pygame.quit()

def tela_7():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_9()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()

    pygame.quit()

#PERGUNTA 2, FASE 1
def config_l2():
    global moedas
    global pontuacao
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_9()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                 como_jogar_l2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao = 0
                moedas  = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()

def como_jogar_l2():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l2()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l2():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l2()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l4():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l5()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l5():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l4()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


def credito_l6():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                config_l5()


            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()



def tela_9():
    global moedas
    global pontuacao
    botao = pygame.Rect(245, 475, 85, 90)
    botao1 = pygame.Rect(730, 480, 85, 85)
    botao2 = pygame.Rect(245, 590, 85, 85)
    botao3 = pygame.Rect(730, 590, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao += 1
                tela_10()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l2()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(acampamento_2, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()


    pygame.quit()

def tela_10():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
               tela_12()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def tela_11():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_12()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#PERGUNTA 3, FASE 1
def config_l3():
    global moedas
    global pontuacao

    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_12()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                 como_jogar_l3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()
def como_jogar_l3():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_4()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def sobre_l3():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l7():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l8()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l8():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l9()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l7()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l9():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                config_l8()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


def tela_12():
    global moedas
    global pontuacao
    botao = pygame.Rect(245, 475, 85, 90)
    botao1 = pygame.Rect(730, 480, 85, 85)
    botao2 = pygame.Rect(245, 590, 85, 85)
    botao3 = pygame.Rect(730, 590, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao += 1
                tela_13()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(acampamento_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()

def tela_13():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_15()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_14():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_15()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#PERGUNTA 4, FASE 1
def config_l4():
    global moedas
    global pontuacao
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_15()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l10()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao = 0
                moedas  = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()
def como_jogar_l4():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l4()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def sobre_l4():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l1()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l10():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l11()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l11():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l12()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l10()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()
def credito_l12():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l11()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_15():
    global moedas
    global pontuacao
    botao = pygame.Rect(550, 500, 85, 90)
    botao1 = pygame.Rect(1045, 500, 85, 85)
    botao2 = pygame.Rect(550, 615, 85, 85)
    botao3 = pygame.Rect(1045, 615, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao += 1
                tela_16()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l4()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(acampamento_4, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_16():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_17():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#FASE 2
def nivell_2():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_g1()
                elif botao3.collidepoint(event.pos):
                    tela_18()
                elif botao4.collidepoint(event.pos):
                    bloqueio_g2()
                elif botao5.collidepoint(event.pos):
                    bloqueio_g3()
                elif botao6.collidepoint(event.pos):
                    bloqueio_g4()
                elif botao7.collidepoint(event.pos):
                    bloqueio_g5()
                elif botao8.collidepoint(event.pos):
                    bloqueio_g6()
                elif botao12.collidepoint(event.pos):
                    config_l5()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao9)
        pygame.draw.rect(tela, BRANCO, botao10)
        pygame.draw.rect(tela, BRANCO, botao11)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_2, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (310, 580))

        pygame.display.flip()

    pygame.quit()

def config_l5():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_1 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))


        pygame.display.flip()

    pygame.quit()


def como_jogar_l5():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l5()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l5():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l5()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l14():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l15()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l15():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l16()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l14()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


def credito_l16():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l15()
            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()



#PERGUNTA 1, FASE 2

def config_l6():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_1 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()

def como_jogar_l6():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l6()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l6():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l6()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l17():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l18()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l18():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l19()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l17()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l19():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l18()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_18():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(105, 445, 85, 90)
    botao1 = pygame.Rect(590, 445, 85, 85)
    botao2 = pygame.Rect(105, 590, 85, 85)
    botao3 = pygame.Rect(590, 590, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_1 += 1
                tela_19()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l6()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cafe_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()
def tela_19():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_21()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def tela_20():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_21()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#pergunta 2, fase 2
def config_l7():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_21()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_1 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()


def como_jogar_l7():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l7()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l7():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l7()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l20():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l21()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l21():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l22()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l20()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l22():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l21()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_21():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(100, 450, 85, 90)
    botao1 = pygame.Rect(550, 450, 85, 85)
    botao2 = pygame.Rect(100, 580, 85, 85)
    botao3 = pygame.Rect(550, 580, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_1 += 1
                tela_22()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l7()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cafe_2, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()
def tela_22():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_24()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_23():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_24()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#pergunta 3, fase 2
def config_l8():
    global moedas
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l8()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l8()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_ll1()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_1 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()


def como_jogar_l8():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l8()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l8():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l8()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_ll1():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_ll2()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_ll2():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_ll3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_ll1()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_ll3():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l8()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_ll2()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_24():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(580, 340, 85, 90)
    botao1 = pygame.Rect(580, 530, 85, 85)
    botao2 = pygame.Rect(1050, 340, 85, 85)
    botao3 = pygame.Rect(1050, 530, 85, 85)
    botao4 = pygame.Rect(1523, 20,60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas += 25
                pontuacao_1 = 1
                tela_25()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l7()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cafe_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()

def tela_25():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_27()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_26():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_27()

        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#pergunta 4, fase 2
def config_l9():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_27()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l9()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l9()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_1 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))
        pygame.display.flip()

    pygame.quit()

def como_jogar_l9():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l9()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def sobre_l9():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l9()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def credito_l23():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l24()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l24():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l25()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l23()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l25():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l9()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l24()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_27():
    global moedas
    global pontuacao_1
    botao = pygame.Rect(510, 400, 85, 90)
    botao1 = pygame.Rect(1050, 400, 85, 85)
    botao2 = pygame.Rect(510, 610, 85, 85)
    botao3 = pygame.Rect(1050, 610, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_1 += 1
                tela_28()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l8()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cafe_4, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_28():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_29():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#NIVEL 3
def nivell_3():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_k1()
                elif botao3.collidepoint(event.pos):
                    concluiu_k2()
                elif botao4.collidepoint(event.pos):
                    tela_30()
                elif botao5.collidepoint(event.pos):
                    bloqueio_k3()
                elif botao6.collidepoint(event.pos):
                   bloqueio_k4()
                elif botao7.collidepoint(event.pos):
                    bloqueio_k5()
                elif botao8.collidepoint(event.pos):
                    bloqueio_k6()
                elif botao12.collidepoint(event.pos):
                    config_l10()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_3, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (300, 580))

        pontos2 = pygame.font.Font(None, 30)
        pontos2 = font.render(str(pontuacao_2) + " / 4", True, PRETO)
        tela.blit(pontos2, (620, 710))

        pygame.display.flip()

    pygame.quit()

def config_l10():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l10()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l10()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)

        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()


def como_jogar_l10():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l10()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def sobre_l10():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l10()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l26():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l27()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l27():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l28()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l26()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l28():
    botao = pygame.Rect(1400, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l10()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l27()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#PERGUNTA 1, NIVEL 3

def config_l11():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_30()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l11():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l11()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l11():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l11()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l29():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l30()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l30():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l31()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l29()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l31():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l11()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l30()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def tela_30():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(90, 395, 85, 90)
    botao1 = pygame.Rect(500, 395, 85, 85)
    botao2 = pygame.Rect(90, 550, 85, 85)
    botao3 = pygame.Rect(500, 530, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_2 += 1
                tela_31()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l12()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(hospital_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_31():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_33()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_32():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_33()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

#configuração
def config_l12():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_30()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l12()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l12()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l12():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l12()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l12():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l12()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l32():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l33()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l33():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l34()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l32()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l34():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l12()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l33()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


#PERGUNTA  2, NIVEL 3

def tela_33():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(90, 350, 85, 90)
    botao1 = pygame.Rect(510, 360, 85, 85)
    botao2 = pygame.Rect(90, 530, 85, 85)
    botao3 = pygame.Rect(510, 530, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                pontuacao_2 += 1
                moedas += 25
                tela_34()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l13()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(hospital_2, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()

def tela_34():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_37()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_35():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_37()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configuração
def config_l13():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_33()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l13()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l13()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l36()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l13():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l13()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l13():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l13()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l35():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l36()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l36():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l37()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l35()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l37():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l13()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l36()


            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#PERGUNTA 3, NIVEL 3
def tela_37():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(90, 410, 85, 90)
    botao1 = pygame.Rect(510, 420, 85, 85)
    botao2 = pygame.Rect(90, 590, 85, 85)
    botao3 = pygame.Rect(510, 585, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                pontuacao_2 += 1
                moedas += 25
                tela_38()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_39()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_39()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_39()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l14()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(hospital_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()
def tela_38():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_40()


        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

def tela_39():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_40()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configuração
def config_l14():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_37()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l36()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l14():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l14()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l14():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l14()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l38():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l39()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l39():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l40()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l38()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l40():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l14()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l39()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#
#PERGUNTA 4, NIVEL 3
def tela_40():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(90, 410, 85, 90)
    botao1 = pygame.Rect(510, 420, 85, 85)
    botao2 = pygame.Rect(90, 590, 85, 85)
    botao3 = pygame.Rect(510, 585, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_42()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_42()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_42()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                pontuacao_2 += 1
                moedas += 25
                tela_41()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l16()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(hospital_4, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))


        pygame.display.flip()


    pygame.quit()
def tela_41():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_42():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configuração
def config_l16():
    global moedas
    global pontuacao_2
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_40()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l16()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l16()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l41()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_2 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l16():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l16()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l16():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l16()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l41():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l42()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l42():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l43()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l43():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l42()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                config_l16()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#NIVEL 4
def nivell_4():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_h1()
                elif botao3.collidepoint(event.pos):
                    concluiu_h2()
                elif botao4.collidepoint(event.pos):
                    concluiu_h3()
                elif botao5.collidepoint(event.pos):
                    tela_95()
                elif botao6.collidepoint(event.pos):
                    bloqueio_h3()
                elif botao7.collidepoint(event.pos):
                    bloqueio_h4()
                elif botao8.collidepoint(event.pos):
                    bloqueio_h7()
                elif botao9.collidepoint(event.pos):
                    print("Botão 9 clicado")
                elif botao10.collidepoint(event.pos):
                    print("Botão 10 clicado")
                elif botao11.collidepoint(event.pos):
                    print("Botão 11 clicado")
                elif botao12.collidepoint(event.pos):
                    config_l17()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao9)
        pygame.draw.rect(tela, BRANCO, botao10)
        pygame.draw.rect(tela, BRANCO, botao11)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_4, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (300, 580))

        pontos2 = pygame.font.Font(None, 30)
        pontos2 = font.render(str(pontuacao_2) + " / 4", True, PRETO)
        tela.blit(pontos2, (620, 710))

        pontos3 = pygame.font.Font(None, 30)
        pontos3 = font.render(str(pontuacao_3) + " / 4", True, PRETO)
        tela.blit(pontos3, (750, 565))

        pygame.display.flip()

    pygame.quit()

#configuração
def config_l17():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l49()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_3 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l17():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l17()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l17():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l17()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l49():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l50()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l50():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l51()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l49()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l51():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l17()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l50()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#
#PERGUNTA 1, NIVEL 4
def tela_95():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(105, 495, 85, 90)
    botao1 = pygame.Rect(600, 495, 85, 85)
    botao2 = pygame.Rect(105, 600, 85, 85)
    botao3 = pygame.Rect(600, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao_3 += 1
                tela_43()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_44()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_44()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_44()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l18()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(escola_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_43():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_45()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_44():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_45()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configuração
def config_l18():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_95()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l52()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_3 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l18():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l18()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l18():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l18()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l52():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l53()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l53():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l54()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l52()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l54():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l53()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 2, NIVEL 4
def tela_45():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(105, 435, 85, 90)
    botao1 = pygame.Rect(600, 435, 85, 85)
    botao2 = pygame.Rect(105, 600, 85, 85)
    botao3 = pygame.Rect(600, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_47()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_47()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas += 25
                pontuacao_3 += 1
                tela_46()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_47()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l19()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(escola_2, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_46():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_51()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_47():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_51()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configurção
def config_l19():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_45()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l18()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l55()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_3 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l19():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l19()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l19():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l19()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l55():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l56()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l56():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l57()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l55()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l57():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l19()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l56()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 3, NIVEL 4
def tela_51():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(105, 435, 85, 90)
    botao1 = pygame.Rect(510, 435, 85, 85)
    botao2 = pygame.Rect(105, 600, 85, 85)
    botao3 = pygame.Rect(510, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_53()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_3 += 1
                tela_52()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_53()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_53()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l20()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(escola_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_52():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_54()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_53():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_54()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#configurção
def config_l20():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_51()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l58()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_3 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l20():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l20()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l20():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l20()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l58():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l59()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l59():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l60()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l58()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l60():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l59()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 4, NIVEL 4
def tela_54():
    global moedas
    botao = pygame.Rect(125, 390, 85, 90)
    botao1 = pygame.Rect(530, 390, 85, 85)
    botao2 = pygame.Rect(125, 555, 85, 85)
    botao3 = pygame.Rect(530, 555, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                tela_55()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_56()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_56()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_56()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l21()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(escola_4, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

#configurção
def config_l21():
    global moedas
    global pontuacao_3
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_54()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l20()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l61()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_3 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l21():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l21()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l21():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l21()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l61():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l62()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l62():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l63()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l61()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l63():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l21()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l62()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def tela_55():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_56():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

#NIVEL 5
def nivell_5():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_t1()
                elif botao3.collidepoint(event.pos):
                    concluiu_t2()
                elif botao4.collidepoint(event.pos):
                    concluiu_t3()
                elif botao5.collidepoint(event.pos):
                    concluiu_t4()
                elif botao6.collidepoint(event.pos):
                    tela_57()
                elif botao7.collidepoint(event.pos):
                    bloqueio_t3()
                elif botao8.collidepoint(event.pos):
                    bloqueio_t7()
                elif botao9.collidepoint(event.pos):
                    print("Botão 9 clicado")
                elif botao10.collidepoint(event.pos):
                    print("Botão 10 clicado")
                elif botao11.collidepoint(event.pos):
                    print("Botão 11 clicado")
                elif botao12.collidepoint(event.pos):
                    config_l22()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao9)
        pygame.draw.rect(tela, BRANCO, botao10)
        pygame.draw.rect(tela, BRANCO, botao11)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_5, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (300, 580))

        pontos2 = pygame.font.Font(None, 30)
        pontos2 = font.render(str(pontuacao_2) + " / 4", True, PRETO)
        tela.blit(pontos2, (620, 710))

        pontos3 = pygame.font.Font(None, 30)
        pontos3 = font.render(str(pontuacao_3) + " / 4", True, PRETO)
        tela.blit(pontos3, (750, 565))

        pontos4 = pygame.font.Font(None, 30)
        pontos4 = font.render(str(pontuacao_4) + " / 4", True, PRETO)
        tela.blit(pontos4, (940, 390))

        pygame.display.flip()

    pygame.quit()

def config_l22():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l22()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l22()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l64()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_4 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l22():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l22()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l22():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l22()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l64():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l65()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l65():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l66()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l64()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l66():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l22()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l65()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 1, NIVEL 5
def tela_57():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(105, 495, 85, 90)
    botao1 = pygame.Rect(530, 495, 85, 85)
    botao2 = pygame.Rect(105, 600, 85, 85)
    botao3 = pygame.Rect(530, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_58()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_59()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_59()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                pontuacao_4 += 1
                tela_59()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l23()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cinema_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_58():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_60()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_59():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_60()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l23():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_57()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l67()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_4 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l23():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l23()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l23():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l23()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l67():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l68()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l68():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l69()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l67()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l69():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l23()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l68()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 2, NIVEL 5
def tela_60():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(105, 495, 85, 90)
    botao1 = pygame.Rect(550, 495, 85, 85)
    botao2 = pygame.Rect(105, 600, 85, 85)
    botao3 = pygame.Rect(550, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_62()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_4 += 1
                tela_61()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_62()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_62()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l24()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cinema_2, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_61():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_63()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_62():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_63()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l24():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_60()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l70()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_4 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l24():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l24()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l24():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l24()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l70():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l71()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l71():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l72()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l70()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l72():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l71()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


# PERGUNTA 3, NIVEL 5
def tela_63():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(130, 495, 85, 90)
    botao1 = pygame.Rect(580, 495, 85, 85)
    botao2 = pygame.Rect(130, 600, 85, 85)
    botao3 = pygame.Rect(580, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao_4 += 1
                tela_64()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_65()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_65()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_65()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l25()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cinema_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_64():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_66()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()
def tela_65():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_66()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l25():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_63()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l24()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l74()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_4 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l25():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l25()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l25():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l25()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l74():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l75()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l75():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l76()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l74()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l76():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1  = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l25()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l75()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 4, NIVEL 5

def tela_66():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(130, 450, 85, 90)
    botao1 = pygame.Rect(580, 450, 85, 85)
    botao2 = pygame.Rect(130, 600, 85, 85)
    botao3 = pygame.Rect(580, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao_4 += 1
                tela_67()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_68()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_68()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_68()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l26()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(cinema_4, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_67():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_68():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l26():
    global moedas
    global pontuacao_4
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_66()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l77()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_4 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l26():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l26()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l26():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l26()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l77():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l78()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l78():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l79()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l77()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l79():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l26()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l78()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#NIVEL 6
def nivell_6():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_m1()
                elif botao3.collidepoint(event.pos):
                    concluiu_m2()
                elif botao4.collidepoint(event.pos):
                    concluiu_m3()
                elif botao5.collidepoint(event.pos):
                    concluiu_m4()
                elif botao6.collidepoint(event.pos):
                    concluiu_m5()
                elif botao7.collidepoint(event.pos):
                    tela_69()
                elif botao8.collidepoint(event.pos):
                    bloqueio_m7()
                elif botao9.collidepoint(event.pos):
                    print("Botão 9 clicado")
                elif botao10.collidepoint(event.pos):
                    print("Botão 10 clicado")
                elif botao11.collidepoint(event.pos):
                    print("Botão 11 clicado")
                elif botao12.collidepoint(event.pos):
                    config_l27()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao9)
        pygame.draw.rect(tela, BRANCO, botao10)
        pygame.draw.rect(tela, BRANCO, botao11)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_6, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (300, 580))

        pontos2 = pygame.font.Font(None, 30)
        pontos2 = font.render(str(pontuacao_2) + " / 4", True, PRETO)
        tela.blit(pontos2, (620, 710))

        pontos3 = pygame.font.Font(None, 30)
        pontos3 = font.render(str(pontuacao_3) + " / 4", True, PRETO)
        tela.blit(pontos3, (750, 565))

        pontos4 = pygame.font.Font(None, 30)
        pontos4 = font.render(str(pontuacao_4) + " / 4", True, PRETO)
        tela.blit(pontos4, (940, 390))

        pontos5 = pygame.font.Font(None, 30)
        pontos5 = font.render(str(pontuacao_5) + " / 4", True, PRETO)
        tela.blit(pontos5, (1200, 320))


        pygame.display.flip()

    pygame.quit()

def config_l27():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l27()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l27()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l80()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_5 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l27():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l27()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l27():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l27()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l80():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l81()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l81():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l82()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l80()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l82():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l27()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l81()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 1, NIVEL 6

def tela_69():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(120, 480, 85, 90)
    botao1 = pygame.Rect(630, 480, 85, 85)
    botao2 = pygame.Rect(120, 600, 85, 85)
    botao3 = pygame.Rect(630, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao_5 += 1
                tela_70()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_71()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_71()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_71()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l28()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(biblioteca_1, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_70():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_72()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_71():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_72()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l28():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_69()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l28()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l28()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l83()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_5 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l28():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l28()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l28():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l28()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l83():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l84()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l84():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l85()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l83()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l85():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l28()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l84()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 2, NIVEL 6
def tela_72():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(100, 350, 85, 90)
    botao1 = pygame.Rect(460, 350, 85, 85)
    botao2 = pygame.Rect(100, 530, 85, 85)
    botao3 = pygame.Rect(460, 530, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_74()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_74()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas += 25
                pontuacao_5 += 1
                tela_73()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_74()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l29()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(biblioteca_2, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_73():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_75()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_74():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_75()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l29():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_72()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l86()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_5 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l29():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l29()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l29():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l29()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l86():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l87()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l87():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l88()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l86()


            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l88():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l29()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l87()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

# PERGUNTA 3, NIVEL 6

def tela_75():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(120, 370, 85, 90)
    botao1 = pygame.Rect(500, 370, 85, 85)
    botao2 = pygame.Rect(120, 555, 85, 85)
    botao3 = pygame.Rect(500, 555, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)


    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_77()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_5 += 1
                tela_76()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_77()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_77()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l30()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(biblioteca_3, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_76():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_78()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_77():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_78()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l30():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_75()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l30()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l30()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l89()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_5 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l30():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l30()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l30():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l30()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l89():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l90()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l90():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l91()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l89()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela


        pygame.display.flip()
    pygame.quit()

def credito_l91():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l30()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l91()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


# PERGUNTA 4, NIVEL 6

def tela_78():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(120, 490, 85, 90)
    botao1 = pygame.Rect(610, 490, 85, 85)
    botao2 = pygame.Rect(120, 600, 85, 85)
    botao3 = pygame.Rect(610, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas += 25
                pontuacao_5 += 1
                tela_79()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_80()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_80()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_80()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l31()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(biblioteca_4, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_79():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_80():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l31():
    global moedas
    global pontuacao_5
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_78()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l31()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l31()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l92()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_5 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l31():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l31()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l31():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l31()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l92():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l93()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l93():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l94()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l92()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l94():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l31()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l93()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


#NIVEL 7

def nivell_7():
    botao2 = pygame.Rect(340, 280, 60, 60)
    botao3 = pygame.Rect(220, 540, 60, 60)
    botao4 = pygame.Rect(545, 645, 60, 60)
    botao5 = pygame.Rect(810, 540, 60, 60)
    botao6 = pygame.Rect(890, 315, 60, 60)
    botao7 = pygame.Rect(1140, 260, 60, 60)
    botao8 = pygame.Rect(1390, 260, 60, 60)
    botao9 = pygame.Rect(20, 200, 80, 160)
    botao10 = pygame.Rect(20, 380, 80, 140)
    botao11 = pygame.Rect(20, 540, 80, 140)
    botao12 = pygame.Rect(1525, 25,60, 60)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN:
                if botao2.collidepoint(event.pos):
                    concluiu_l1()
                elif botao3.collidepoint(event.pos):
                    concluiu_l2()
                elif botao4.collidepoint(event.pos):
                    concluiu_l3()
                elif botao5.collidepoint(event.pos):
                    concluiu_l4()
                elif botao6.collidepoint(event.pos):
                    concluiu_l5()
                elif botao7.collidepoint(event.pos):
                    concluiu_l7()
                elif botao8.collidepoint(event.pos):
                    tela_81()
                elif botao9.collidepoint(event.pos):
                    print("Botão 9 clicado")
                elif botao10.collidepoint(event.pos):
                    print("Botão 10 clicado")
                elif botao11.collidepoint(event.pos):
                    print("Botão 11 clicado")
                elif botao12.collidepoint(event.pos):
                    config_l32()

        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)
        pygame.draw.rect(tela, BRANCO, botao5)
        pygame.draw.rect(tela, BRANCO, botao6)
        pygame.draw.rect(tela, BRANCO, botao7)
        pygame.draw.rect(tela, BRANCO, botao8)
        pygame.draw.rect(tela, BRANCO, botao9)
        pygame.draw.rect(tela, BRANCO, botao10)
        pygame.draw.rect(tela, BRANCO, botao11)
        pygame.draw.rect(tela, BRANCO, botao12)

        tela.fill((50, 100, 200))
        tela.blit(nivel_7, (0, 0))

        font = pygame.font.Font(None, 36)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pontos = pygame.font.Font(None, 30)
        pontos = font.render(str(pontuacao) + " / 4", True, PRETO)
        tela.blit(pontos, (400, 340))

        pontos1 = pygame.font.Font(None, 30)
        pontos1 = font.render(str(pontuacao_1) + " / 4", True, PRETO)
        tela.blit(pontos1, (300, 580))

        pontos2 = pygame.font.Font(None, 30)
        pontos2 = font.render(str(pontuacao_2) + " / 4", True, PRETO)
        tela.blit(pontos2, (620, 710))

        pontos3 = pygame.font.Font(None, 30)
        pontos3 = font.render(str(pontuacao_3) + " / 4", True, PRETO)
        tela.blit(pontos3, (750, 565))

        pontos4 = pygame.font.Font(None, 30)
        pontos4 = font.render(str(pontuacao_4) + " / 4", True, PRETO)
        tela.blit(pontos4, (940, 390))

        pontos5 = pygame.font.Font(None, 30)
        pontos5 = font.render(str(pontuacao_5) + " / 4", True, PRETO)
        tela.blit(pontos5, (1200, 320))

        pontos6 = pygame.font.Font(None, 30)
        pontos6 = font.render(str(pontuacao_6) + " / 4", True, PRETO)
        tela.blit(pontos6, (1450, 305))

        pygame.display.flip()

    pygame.quit()

def config_l32():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l95()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_6 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l32():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l32()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l32():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l32()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l95():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l96()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l96():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l97()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l95()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l97():
    botao = pygame.Rect(1400, 740, 70, 70)
    botao1 = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l32()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l96()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#PERGUNTA 1, NIVEL 7
def tela_81():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(100, 500, 85, 90)
    botao1 = pygame.Rect(565, 500, 85, 85)
    botao2 = pygame.Rect(100, 620, 85, 85)
    botao3 = pygame.Rect(565, 620, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_83()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_83()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_83()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                pontuacao_6 += 1
                tela_82()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l33()


        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(mercadinho_1, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_82():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_84()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_83():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_84()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l33():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_81()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l33()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l33()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l98()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_6 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l33():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l33()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l33():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l33()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l98():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l99()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l99():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l100()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l98()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l100():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l33()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l99()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#PERGUNTA 2, NIVEL 7

def tela_84():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(150, 500, 85, 90)
    botao1 = pygame.Rect(565, 500, 85, 85)
    botao2 = pygame.Rect(150, 600, 85, 85)
    botao3 = pygame.Rect(565, 600, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_86()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_85()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_86()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                pontuacao_6 += 1
                tela_85()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l34()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(mercadinho_2, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_85():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_87()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_86():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_87()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l34():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_84()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l34()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l34()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l101()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_6 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l34():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l34()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l34():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l34()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l101():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l102()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l102():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l103()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l101()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l103():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l34()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l102()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#PERGUNTA 3, NIVEL 7

def tela_87():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(150, 550, 85, 90)
    botao1 = pygame.Rect(585, 550, 85, 85)
    botao2 = pygame.Rect(150, 650, 85, 85)
    botao3 = pygame.Rect(585, 650, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_89()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas += 25
                pontuacao_6 += 1
                tela_90()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_90()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas -= 10
                tela_90()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l35()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(mercadinho_3, (0, 0))  # Exibe a imagem na quarta tela


        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_89():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_91()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_90():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_91()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l35():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_87()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l104()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_6 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l35():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l35()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l35():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l35()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l104():
    botao = pygame.Rect(1400, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l105()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l105():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l106()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l104()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela
            pygame.draw.rect(tela, BRANCO, botao)

        pygame.display.flip()
    pygame.quit()

def credito_l106():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l35()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l105()

            pygame.draw.rect(tela, BRANCO, botao)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()


#PERGUNTA 4, NIVEL 7
def tela_91():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(150, 550, 85, 90)
    botao1 = pygame.Rect(585, 550, 85, 85)
    botao2 = pygame.Rect(150, 650, 85, 85)
    botao3 = pygame.Rect(585, 650, 85, 85)
    botao4 = pygame.Rect(1523, 20, 60, 60)
    running = True


    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                moedas -= 10
                tela_92()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                moedas -= 10
                tela_93()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                moedas -= 10
                tela_93()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                moedas += 25
                pontuacao_6 += 1
                tela_93()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                config_l36()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        pygame.draw.rect(tela, BRANCO, botao4)

        tela.fill((150, 150, 150))
        tela.blit(mercadinho_4, (0, 0))  # Exibe a imagem na quarta tela



        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (1410, 40))

        pygame.display.flip()

    pygame.quit()

def tela_92():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_94()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(acerto, (0, 0))  # Exibe a imagem na quarta tela
        pygame.display.flip()

    pygame.quit()

def tela_93():
    botao = pygame.Rect(690, 315, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_94()
        pygame.draw.rect(tela, BRANCO, botao)

        tela.fill((150, 150, 150))
        tela.blit(erro, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def config_l36():
    global moedas
    global pontuacao_6
    botao = pygame.Rect(1425, 70, 70, 70)
    botao1 = pygame.Rect(830, 130, 550, 100)
    botao2 = pygame.Rect(830, 320, 550, 100)
    botao3 = pygame.Rect(830, 500, 550, 100)
    botao4 = pygame.Rect(830, 650, 550, 100)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_91()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                como_jogar_l36()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao2.collidepoint(event.pos):
                sobre_l36()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao3.collidepoint(event.pos):
                credito_l107()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao4.collidepoint(event.pos):
                pontuacao_6 = 0
                moedas = 0
                tela_3()

        pygame.draw.rect(tela, BRANCO, botao)
        pygame.draw.rect(tela, BRANCO, botao1)
        pygame.draw.rect(tela, BRANCO, botao2)
        pygame.draw.rect(tela, BRANCO, botao3)
        tela.fill((150, 150, 150))
        tela.blit(config_jogo, (0, 0))

        pygame.display.flip()

    pygame.quit()

def como_jogar_l36():
    botao = pygame.Rect(1425, 75, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l36()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(como_jogar_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def sobre_l36():
    botao = pygame.Rect(1425, 70, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l36()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(sobre_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()
def credito_l107():
    botao = pygame.Rect(1400,740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l108()

        pygame.draw.rect(tela, BRANCO, botao)
        tela.fill((150, 150, 150))
        tela.blit(criadores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()

def credito_l108():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                credito_l109()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l107()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(instrutores, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

def credito_l109():
    botao = pygame.Rect(1400, 75, 70, 70)
    botao1 = pygame.Rect(150, 740, 70, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                config_l36()
            elif event.type == pygame.MOUSEBUTTONDOWN and botao1.collidepoint(event.pos):
                credito_l108()

            pygame.draw.rect(tela, BRANCO, botao)
            pygame.draw.rect(tela, BRANCO, botao1)
            tela.fill((150, 150, 150))
            tela.blit(agradecimento_1, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()
    pygame.quit()

#FINAL PORAAAAAAAAA
def tela_94():
    botao = pygame.Rect(900, 700, 80, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_100()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(final, (0, 0))  # Exibe a imagem na quarta tela

        font = pygame.font.Font(None, 40)
        text = font.render(" " + str(moedas), True, PRETO)
        tela.blit(text, (150, 50))

        pygame.display.flip()

    pygame.quit()

def tela_100():
    botao = pygame.Rect(980, 650, 240, 70)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                pygame.quit()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill((150, 150, 150))
        tela.blit(final_15, (0, 0))  # Exibe a imagem na quarta tela

        pygame.display.flip()

    pygame.quit()


def bloqueio_f1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_1, (0, 0))


        pygame.display.flip()

    pygame.quit()


def bloqueio_f2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_2, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_f3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_3, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_f4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_4, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_f5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_5, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_f6():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_f7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()


def concluiu_f1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_4, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_5, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f6():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_f7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                tela_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_7, (0, 0))

        pygame.display.flip()

    pygame.quit()
#telas nivel 2
def concluiu_g1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

def bloqueio_g2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_2, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_g3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_3, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_g4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_4, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_g5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_5, (0, 0))

        pygame.display.flip()
    pygame.quit()


def bloqueio_g6():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_g7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_2()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

#nivel3 telas
def concluiu_k1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_k2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def bloqueio_k3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_3, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_k4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_4, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_k5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_5, (0, 0))

        pygame.display.flip()
    pygame.quit()


def bloqueio_k6():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()


def bloqueio_k7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_3()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()
#nivel 4 telas

def bloqueio_h3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def bloqueio_h4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()
def bloqueio_h7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_h1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_h2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_h3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_4()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

#telas nivel 5

def concluiu_t1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_t2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_t3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_t4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_4, (0, 0))

        pygame.display.flip()

    pygame.quit()

def bloqueio_t3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def bloqueio_t7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_5()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

#telas nivel 6
def bloqueio_m7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(bloqueio_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_m1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_m2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_m3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_m4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_4, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_m5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_6()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_5, (0, 0))

        pygame.display.flip()

    pygame.quit()

#telas nivel 7

def concluiu_l1():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_1, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l2():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_2, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l3():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_3, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l4():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_4, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l5():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_5, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l6():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_6, (0, 0))

        pygame.display.flip()

    pygame.quit()

def concluiu_l7():
    botao = pygame.Rect(1150, 230, 50, 50)
    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            elif event.type == pygame.MOUSEBUTTONDOWN and botao.collidepoint(event.pos):
                nivell_7()

        pygame.draw.rect(tela, PRETO, botao)
        tela.fill(BRANCO)
        tela.blit(concluiu_7, (0, 0))

        pygame.display.flip()

    pygame.quit()







tela_1()